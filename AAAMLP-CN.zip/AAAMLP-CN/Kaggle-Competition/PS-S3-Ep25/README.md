# Playground-Series-S3E25

## 数据来源

- 数据来自Kaggle，[数据说明](https://www.kaggle.com/competitions/playground-series-s3e25/data)
- 此次比赛是回归问题，但最后大家发现转换成分类得到的结果居然会更好
- 在Private排行榜上前189名得分完全一致，均为0.25，是一场非常有意思的比赛

## 解决方案

### 1th-place-solution

- 第1名解决方案来自**Oscar Aguilar**，[个人主页](https://www.kaggle.com/oscarm524)
- 解决方案原[jupyter notebook](https://www.kaggle.com/code/oscarm524/ps-s3-ep25-eda-modeling-submission)